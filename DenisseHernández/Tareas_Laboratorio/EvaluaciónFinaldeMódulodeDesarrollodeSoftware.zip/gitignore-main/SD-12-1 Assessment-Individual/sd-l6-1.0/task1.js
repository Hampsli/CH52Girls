// Task 1: getServerURL()

export function getServerURL() {
    return "http://localhost:3000/users"; // Replace with the actual server URL if different
}