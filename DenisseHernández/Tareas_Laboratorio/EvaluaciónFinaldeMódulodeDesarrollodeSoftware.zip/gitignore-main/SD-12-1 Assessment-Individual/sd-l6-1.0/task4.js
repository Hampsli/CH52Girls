// Task 4: delUser(number)

import axios from "axios";

const SERVER_URL = "http://localhost:3000/users"; // URL del servidor JSON

const delUser = async (id) => {
  try {
    // Verificar si el usuario existe antes de eliminarlo
    const response = await axios.get(`${SERVER_URL}/${id}`);
    
    if (!response.data) {
      console.log(`⚠️ No se encontró un usuario con ID ${id}`);
      return;
    }

    // Enviar la solicitud DELETE al servidor JSON
    await axios.delete(`${SERVER_URL}/${id}`);

    console.log(`✅ Usuario con ID ${id} eliminado con éxito`);
  } catch (error) {
    console.error("❌ Error al eliminar usuario:", error.message);
  }
};

// Ejecutar la función directamente para probar (puedes cambiar el ID)
delUser(8);
