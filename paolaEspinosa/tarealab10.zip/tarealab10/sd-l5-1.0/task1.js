/*Tarea 1: María está calculando el coste de los pagos mensuales. Por cada transacción hay una tarifa de $ 3 y
 una tarifa de interés del 1% (0.01). 
Dada una cantidad de transacción de entrada, exporte una función que devuelva el valor de lo que debería estar pagando.
Esta función debe ser capaz de tomar un número como entrada y devolver un número como salida.
*/


export function costCalculator(number) {
        let pago = (number*0.01) + 3 + number;
        return pago;
}

const resultado = costCalculator(124);
console.log(resultado);
