/*Tarea 3: A Javiera le gustaría una forma de calcular una edad a partir de una fecha de nacimiento determinada.
Exporte una función que requerirá 3 argumentos - un año, un mes y un día, y luego devuelva una edad precisa.
Por ejemplo, ageCalculator(2000, 12, 25) debe devolver la edad de alguien nacido el día de Navidad de 2000.
*/
export function ageCalculator(year,month,day) {
        const currentDate = new Date(2025, 1, 12); // Fecha simulada: 12 de febrero de 2025
        const birthDate = new Date(year, month - 1, day); // Restar 1 al mes porque Date usa meses basados en 0
    
        let edad = currentDate.getFullYear() - birthDate.getFullYear();
    
        // Ajustar la edad si el cumpleaños aún no ha pasado este año
            if (
            currentDate.getMonth() < birthDate.getMonth() ||
            (currentDate.getMonth() === birthDate.getMonth() && currentDate.getDate() < birthDate.getDate())
            ) {
            edad--;
            }
        return edad;
       
} 

let fechaNacimiento = ageCalculator( 2001, 12, 25);
console.log(fechaNacimiento, "years old");

