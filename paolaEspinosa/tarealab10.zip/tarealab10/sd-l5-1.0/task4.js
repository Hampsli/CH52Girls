/*Tarea 4: A Javiera le gustaría una forma de calcular las edades de sus amigos.
Exporta una clase que devolverá una cadena que contiene el nombre y la edad de un amigo determinado. Deberia:
Toma 4 argumentos - a nombre, a año, a mes, y a día -y construye un objeto con esas 4 propiedades. 
Tener un método público llamado returnAge()que devolverá la siguiente cadena:  <nombre> is <edad> hoy!*/

export class FriendAge {
    constructor(name,year,month,day){
        this.name = name;
        this.year = year;
        this.month = month;
        this.day = day;
    }
    returnAge(){

        const currentDate = new Date(2025, 1, 12); // Fecha simulada: 12 de febrero de 2025
        const birthDate = new Date(this.year,this.month - 1,this.day); // Restar 1 al mes porque Date usa meses basados en 0
    
        let edad = currentDate.getFullYear() - birthDate.getFullYear();
    
        // Ajustar la edad si el cumpleaños aún no ha pasado este año
            if (
             currentDate.getMonth() < birthDate.getMonth() ||
             (currentDate.getMonth() === birthDate.getMonth() && currentDate.getDate() < birthDate.getDate())
            ) {
             edad--;
            }
        return (`${this.name} is ${edad} today`);
    }
}

const usuario1 = new FriendAge("Kimi",1998,11,5);
console.log(usuario1.returnAge());



