/*Ciclos/Bucles/loops
Son una estructura de codigo que nos permiten ejecutar una instruccion de forma repetida, siempre y cuando cumple la condicion. Son estructura de control.
estos ciclos estan vinculados a variable y condiciones, es importante que nuestros ciclos sean finitos*/

/*While 
se sigue ejecutando hasta que la condicion sea falsa, primero pregunta y luego ejecuta*/

/*let numero=0
while( numero <=5){
    console.log(numero);
    numero++
}*/

//do while, primero ejecuta y despues pregunta la condicion
let numero = 0;
do{
    console.log(numero);
    numero++
}
while(numero <=5);

//break nos  permite detener el dclo con base en lo que necesites

while(numero < 100){
    console.log(numero);
    numero ++
    if (numero ==10){
        break;
    }
}

/* ciclo for 
se compone de tres partes, una es declarando mi variable,
inicializando e iterando*/

for( let i= 0; i<6; i++){

    document.write(i)
}

//investigar el ciclo for in y for off

/*Arrays es una estructura de datos en este caso una lista,con datos que comparten caracteristicas.
Dentro de un array los elementos cuentan con un indice que empieza en 0 y una posicion que inicia en 1.*/

let frutas = [ `papaya`,`platano`,`mango`, `fresa`,`tuna`];
console.log(frutas);
frutas.splice(1,0,`uva`) //anade
console.log(frutas)
frutas.splice(2,4) //borra
console.log(frutas)

//metodo splice
//agrega o borra un(os) elemento(s) en medio de dos posiciones

//metodo shift Elimina el primer elemento
//metodo pop Elimina el ultimo

//objetos/ diccionario
const usuarixs= {
    "nombre" : "Paola",
    "edad":"29",
    "correo":"paospinoza1@gmail.com",
    "telefono":"5512900501"
}

console.log(usuarixs.edad)

/*Funciones son bloques de codigo que nos permiten modularizar
y se pueden ejecutar en cualquier parte del codigo, siempre y cuando
las mande llamar*/

function consejo(){
    let clima = prompt("como esta el clima hoy");
    if (clima == "Caluroso"){
        alert("toma agua")
    } else{
        alert("abrigate");
    }
}

// Un array de días de la semana
const WEEKDAYS = [
    "Lunes",
    "Martes",
    "Miércoles",
    "Jueves",
    "Viernes",
    "Sábado",
    "Domingo"
    ]
    // Problema 1: Bucles
    // Este bucle for se ejecutará una vez por cada elemento en el array WEEKDAYS.
    for (let element in WEEKDAYS) {
    console.log("El bucle está en la posición " + element) //HABIA UNAS COMILLAS QUE NODEBERIAN IR, ANTES DE CONSOLE
    }
    
    
    // Error 1: ReferenceError: elemento no está definido
    for(let element in WEEKDAYS){
    console.log("El día en la posición " + element + " es " + WEEKDAYS[element])
    } //SE INCLUYE UN CICLO FOR PARA QUE PUEDA RECORRER CADA ELEMENTO DEL ARRAY Y EJECUTAR LA TAREA, ADEMAS DE QUE PUEDE HACER USO DE LA VARIABLE ELEMENT
    
    
    // Problema 2: Ramas (Branches)
    // Este bloque de código verificará si cada elemento en el array WEEKENDS es sábado O domingo
    for (let element of WEEKDAYS) { //SE CAMBIA FOR IN POR FOR ON PARA RECORRER LOS VALORES DEL ARREGLO
        if (element === "Sábado" || element === "Domingo") {
          let weekend = true;  
          // Error 2: ReferenceError: weekend no está definido
          //SE METE WEEKEND DENTRO DEL PRIMERO IF PARA QUE OCUPE LA MISMA VARIABLE
            if (weekend === true) {
              console.log("It's a Weekend" + " " + element)
            }
        }   
    }


    // Problema 3: Funciones
    // Esta función comprobará si un número de día de entrada corresponde a un día laborable
    function workdayChecker(dayNumber) {
     let workday = true
        if (WEEKDAYS[dayNumber] === "Saturday" || WEEKDAYS[dayNumber] === "Sunday") {
         workday = false
        }
     return workday
    }

    let workday = workdayChecker(4); //SE DEFINE UNA VARIABLE WORKDAR QUE GUARDE LO QUE REGRESA LA FUNCION
    // Error 3: ReferenceError: workday no está definido
    console.log(workday) 






