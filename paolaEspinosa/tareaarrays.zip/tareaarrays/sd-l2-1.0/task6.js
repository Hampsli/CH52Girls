/*Utilice `concat()` para fusionar las dos matrices dadas, arr1 y arr2, en orden, 
y luego imprima la nueva matriz que se crea*/

const arr1 = ["hello"]
const arr2 = ["world"]

// Type your code below this line!

let union = arr1.concat(arr2);

console.log(union);
