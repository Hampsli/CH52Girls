/*En este ejercicio se utilizael método `arr.push()` 
para completar una matriz vacía con los números del 1 al 20, en orden*/

const arr = []
// Type your code below this line!
for(let numero = 1; numero <=20; numero ++){
  arr.push(numero)
}
// Type your code above this line!
arr.forEach(element => console.log(element))
