/*Aqui se utiliza el método `arr.splice()` para eliminar uno de los dos números duplicados en la matriz dada*/


const arr = [1,2,3,4,5,5,6,7,8,9,10,11,12,13,14]

// Type your code below this line!


arr.splice(4,1) //indica que en el indice 4, se eliminara un elemento

// Type your code above this line!

arr.forEach(element => console.log(element))