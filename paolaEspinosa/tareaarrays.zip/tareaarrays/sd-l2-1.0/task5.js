/*Utilice `join()` en la matriz dada para imprimir una cadena de números de ella, separados solo por comas, ¡sin espacios!*/

const arr0 = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24]

// Type your code below this line!

console.log(arr0.join(","));

