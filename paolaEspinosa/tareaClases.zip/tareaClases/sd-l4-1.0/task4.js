/*ahora se te ha pedido que incluyas un método para subir de nivel a un jugador,
 incrementando su número de nivel en uno.
* Modifica la clase Jugador para que acepte una cadena de nombre de Jugador y 
un número de nivel en dos argumentos separados.
* Luego, define un método de objeto compartido `info()` que imprimirá la siguiente cadena:
* `<name> ha alcanzado el nivel <level>`!
* Finalmente, define un segundo método de objeto compartido llamado `levelUp()` que 
**incrementará** el nivel del Jugador.*/


export class Player {
    constructor(name, level) {
      this.name = name;
      this.level = level;
      this.info = function(){
        console.log(`${name} has reached Level ${level}`)
      }
      this.levelUp = function(){
         const incrementoLevel = parseInt(level) + 1;
         console.log(`${name} has reached Level ${incrementoLevel}!`)
      }
      
    }
    
  }

  const gamer = new Player("Grog","4!");
  gamer.info();
  gamer.levelUp();
