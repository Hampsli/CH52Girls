/*3. Ahora se le ha pedido que incluya un método que envíe una cadena a la consola anunciando un aumento de nivel.
* Modifique la clase Jugador para que acepte una cadena de nombre de jugador y un número de nivel en dos argumentos
 separados.
* Luego, define un método de objeto compartido `info()` que imprimirá la siguiente cadena, 
reemplazando los dos marcadores de posición:
* `<name> ha alcanzado el nivel <level>!`
* Un jugador llamado **Tara** en el nivel **6** debería generar "`Tara ha alcanzado el nivel 6!`
" impreso en la consola.*/

export class Player {
  constructor(name, level) {
     this.name = name;
     this.level = level;
     this.info = function(){
      console.log(`${name} has reached Level ${level}`)
    };
  }
}

const gamer = new Player("Grog","4!");
gamer.info();






