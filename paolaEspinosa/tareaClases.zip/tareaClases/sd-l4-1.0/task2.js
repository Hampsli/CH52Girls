
/*2. Ahora se le ha pedido que mejore su código, de modo que los objetos de jugador puedan definir 
tanto un nombre como un número de nivel.
* Modifique la clase Jugador para que acepte una cadena de "nombre" de Jugador y un número 
de "**nivel**" en dos argumentos separados.
* La clave de esta propiedad en el objeto resultante **debe** ser "`nivel`" - 
¡recuerde, **las computadoras son muy literales**!*/

export class Player {
  constructor(name, level) {
    this.name = name;
    this. level = level;
  }
 }
