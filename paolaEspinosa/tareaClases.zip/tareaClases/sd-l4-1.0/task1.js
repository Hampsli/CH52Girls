/*1. Estás trabajando en un código que se utilizará en un videojuego. Se te ha pedido que crees una clase de objeto.
Estos se utilizarán para definir jugadores en ese juego. Cada jugador puede elegir su propio nombre y estos objetos 
se utilizarán para almacenarlos.
* Modifica la clase Jugador para que acepte un "**nombre**" de Jugador en un argumento.
* La clave de esta propiedad en el objeto resultante **debe** ser "`nombre`" - ¡recuerde,
 **las computadoras son muy literales**!*/

export class Player {
    constructor(name) {
      this.name = name;
    }
  }
