def addmultiplenumbers( num1,num2,num3, num4) :
    suma = num1 + num2 + num3 + num4
    return suma
def multiplymultiplenumbers(num1,num2,num3,num4):
    multiplica = num1 * num2 * num3 * num4
    return multiplica
def isiteven(num):
    if num % 2 == 0:
     return True
    else: return False
def isitaninteger(num):
    if num % 2 == 1:
     return True
    else: return False

def main():
  resultado1 = addmultiplenumbers(2,3.5,5,6)
  print(f"El resultado de la suma de esos numeros es: {resultado1}")

  resultado2 = multiplymultiplenumbers(2,3,5,6)
  print(f"El resultado de la multiplicacion de esos numeros es: {resultado2}")

  resultado3 = isiteven(2)
  print(f"El primer numero es par: {resultado3}")

  resultado4 = isiteven(5)
  print(f"El segundo numero es impar: {resultado4}") 
  
if __name__=="__main__":
    main()

#Lineas para declar variable que tomen los numeros dela  entrada del usuario
#print("Ingresa 4 numeros de un digito")
  #numeroUsuario1=int(input())
  #numeroUsuario2=int(input())
  #numeroUsuario3=int(input())
  #numeroUsuario4=int(input())
  #print(numeroUsuario1,numeroUsuario2,numeroUsuario3,numeroUsuario4)