/*4. Para esta tarea, deberá escribir su propio constructor.
* Cree un constructor llamado Journey que tome dos parámetros: inicio y fin.
* Cree un par de constantes llamadas from y to, y asígneles los valores de los argumentos de la línea de comandos.*/


// Type your code below this line!
function Journey(start,end){
    this.start = start;
    this.end = end;
}

let from = "Queens";
let to = "Brooklyn";
// Type your code above this line!
const travel = new Journey(from, to)

console.log("Booking a taxi from " + travel.start + " to " + travel.end + ".")
