/*2. Se le ha presentado un constructor para un objeto Mail.
* Modifique el código para que el usuario proporcione su propio asunto y mensaje como parámetros de ejecución en ese orden.
* Los parámetros de ejecución son los valores que se pasan a un programa cuando se ejecuta.
* Por ejemplo, si el usuario ejecuta el programa con el comando `node index.js 2 hello world`, entonces "node" es el programa, "index.js" es el primer parámetro, "2" es el segundo parámetro y "hello" y "world" son el tercer y cuarto parámetro respectivamente.
* Puede acceder a los parámetros de ejecución en su programa utilizando la matriz `process.argv`.
* En el ejemplo, el proceso y el primer parámetro (índice 0 y 1 de la matriz `process.argv`) son "node" e "index.js", por lo que puede ignorarlos.
* El segundo parámetro (índice 2) lo utiliza este programa para determinar el número de tarea a ejecutar, por lo que también puede ignorarlo.
* Puede acceder al asunto y al mensaje utilizando `process.argv[3]` y `process.argv[4]` respectivamente.*/

function Mail(subj, msg) {
    this.subject = subj
    this.message = msg
  }
  
  // Type your code below this line!
  
 // let asuntoUsuario = prompt("Define un asunto"); el comando prompt no funciona en la consola node.js pero si es valido para HTML
//let mensajeUsuario = prompt("define un mensaje");

  const newMail = new Mail(process.argv[3],process.argv[4])
  
  // Type your code above this line!
  
  console.log(newMail.subject + ": " + newMail.message)

