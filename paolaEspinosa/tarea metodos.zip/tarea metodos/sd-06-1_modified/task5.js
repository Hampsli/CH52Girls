/*Crea un constructor para un objeto FriendsList que almacenará una lista de nombres en una matriz.
* Tu programa debe solicitarle al usuario un número y luego solicitar esa cantidad de veces para enumerar cada nombre de a uno por vez.
* Tu programa debe imprimir la matriz directamente en la consola.
* La salida debe verse así: `[ 'name1', 'name2' ]`*/

function FriendsList(nombres){
    this.nombres = function(){
        
    }
}


// Type your code below this line!



// Type your code above this line!

