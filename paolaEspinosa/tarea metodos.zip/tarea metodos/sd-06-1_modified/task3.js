/*Se le ha presentado un constructor para un objeto Mail.
* Modifique el código para que el usuario proporcione su propio asunto y mensaje como parámetros de ejecución en ese orden.
* Luego, amplíe el constructor para incluir un método printMail() que imprima lo siguiente en la consola:
* `<subj>: <msg>`
* Por ejemplo, si las dos entradas son `hello` y `world`, entonces la salida debería ser `hello: world`.*/

// Type your code below this line!

function Mail(subj, msg) {
    this.subject = subj
    this.message = msg
    this.printMail= function(){
      console.log(subj,`:`,msg);
    }
    
  }
  const newMail = new Mail(process.argv[3],process.argv[4])
  
  // Type your code above this line!
  
  newMail.printMail()
