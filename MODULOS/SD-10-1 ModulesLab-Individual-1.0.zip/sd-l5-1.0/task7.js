export function rubricPerfect() {

}