export function costCalculator() {

}