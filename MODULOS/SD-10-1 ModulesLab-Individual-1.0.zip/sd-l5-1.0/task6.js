export function rubricExcellent() {

}