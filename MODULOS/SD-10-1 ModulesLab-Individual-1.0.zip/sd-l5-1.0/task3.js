export function ageCalculator() {

}