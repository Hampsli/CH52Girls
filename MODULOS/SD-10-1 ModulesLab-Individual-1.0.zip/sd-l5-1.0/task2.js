export class FriendNames {
    constructor() {
  
    }
  }