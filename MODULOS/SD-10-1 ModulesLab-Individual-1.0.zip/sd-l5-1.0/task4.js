

export class FriendAge {

}