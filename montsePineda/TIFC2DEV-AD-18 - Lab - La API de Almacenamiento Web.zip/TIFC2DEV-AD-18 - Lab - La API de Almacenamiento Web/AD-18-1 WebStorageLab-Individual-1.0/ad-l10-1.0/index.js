const itemsContainer = document.querySelector("#list-items")

function addItem(item) {
  const colourCard = document.createElement("section")
  colourCard.className = "card w-75"
  itemsContainer.append(colourCard)

  const colourCardBody = document.createElement("article")
  colourCardBody.className = "card-body"
  colourCard.append(colourCardBody)

  const colourCardTitle = document.createElement("h5")
  colourCardTitle.className = "card-title"
  colourCardTitle.innerText = item.name
  colourCardBody.append(colourCardTitle)

  const colourCardText = document.createElement("p")
  colourCardText.className = "card-text"
  colourCardText.innerText = item.pantone_value
  colourCardBody.append(colourCardText)

  const colourCardColour = document.createElement("figure")
  colourCardColour.style = "background-color: " + item.color + ";"
  colourCardColour.innerText = item.color
  colourCardBody.append(colourCardColour)

  const colourCardBreak = document.createElement("br")
  itemsContainer.append(colourCardBreak)
}


function fetchColorsList() {
  /*Tarea 1: Implementar la función fetchColorsList() utilizando la API Fetch para descargar la lista completa de colores desde el
siguiente endpoint:
https://reqres.in/api/unknown */

  fetch("https://reqres.in/api/unknown")
  .then(response => response.json())
  .then(data => {
    const colors = data.data; // La API devuelve un objeto con 'data' donde están los colores
    localStorage.setItem("colors", JSON.stringify(colors)); // Guardar en localStorage
    //Se devuelve la lista de colores en una cadena, en el array colors

    itemsContainer.innerHTML = ""; // Limpiar lista antes de cargar los datos almacenados

      /*Tarea 2: Conectar fetchColorsList() con la función addItem() para que la lista de colores se rellene y se muestre en
      index.html. */  
  //Se leen los datos de color y se ponen en la función addItem 
  colors.forEach(addItem);
  }) 
  
}

function loadColorsFromStorage() {
  const storedColors = localStorage.getItem("colors");

  if (storedColors) {
    const colors = JSON.parse(storedColors);
    
    itemsContainer.innerHTML = ""; // Limpiar lista antes de cargar los datos almacenados
    colors.forEach(addItem);
  } else {
    console.log("No hay colores almacenados en localStorage.");
  }
}


//Llamamos a las funciones
fetchColorsList()
loadColorsFromStorage()